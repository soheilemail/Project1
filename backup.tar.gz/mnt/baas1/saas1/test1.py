import json
import urllib.parse

t = 'a="s"&r="7"&f=554545&1=g'
d=dict(urllib.parse.parse_qsl(t))
#d=dict(x.split("=") for x in t.split("&"))

print (d)

print (json.dumps(d))

#print (json.loads (t))
